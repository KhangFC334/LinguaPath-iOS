# LinguaPath iOS — bản mẫu học ngoại ngữ

Dự án SwiftUI độc lập dành cho iPhone (iOS 17 trở lên), có thể build trên GitHub Actions bằng máy chủ macOS. Đây **không phải** bản chuyển đổi APK Duolingo, không dùng mã nguồn/tài nguyên độc quyền của Duolingo và không mở khóa thuê bao của dịch vụ đó.

## Tính năng hiện có
- Màn hình lộ trình học.
- Bài học mẫu tiếng Pháp–Việt với câu hỏi trắc nghiệm, phản hồi đúng/sai.
- Phát âm tiếng Pháp bằng AVSpeechSynthesizer của iOS.
- Từ vựng, XP, số bài hoàn thành và tiến độ lưu bằng UserDefaults.
- Không có quảng cáo trong ứng dụng mẫu.

## Build bằng điện thoại qua GitHub Actions
1. Giải nén ZIP và tạo một repository GitHub mới.
2. Tải toàn bộ nội dung thư mục `LinguaPath-iOS` lên repository, bảo đảm thư mục `.github/workflows/build-unsigned-ipa.yml` được giữ nguyên.
3. Mở tab **Actions** của repository.
4. Chọn workflow **Build unsigned iOS package** rồi nhấn **Run workflow** (hoặc đợi workflow chạy sau khi push lên nhánh `main`).
5. Khi chạy thành công, mở lần chạy đó và tải artifact **LinguaPath-unsigned-ipa**.

## Quan trọng về cài đặt
Workflow tạo gói `.ipa` **chưa ký (unsigned)** để kiểm tra việc build. iPhone không thể cài trực tiếp gói unsigned. Muốn cài lên iPhone 14 Plus cần ký bằng chứng chỉ và provisioning profile hợp lệ của Apple, hoặc dùng quy trình sideload hợp lệ. Không gửi Apple ID, mật khẩu, mã 2FA hay chứng chỉ riêng tư vào chat hoặc repository.

## Build và ký chính thức
Trên máy Mac, mở `LinguaPath.xcodeproj` bằng Xcode, chọn Apple Development Team, đổi Bundle Identifier `com.example.linguapath` thành mã duy nhất của bạn, sau đó Archive và Distribute App.

## Giới hạn
- Đây là ứng dụng mẫu độc lập, không phải Duolingo và không có tài khoản/đồng bộ Duolingo.
- Nội dung khóa học hiện là dữ liệu minh họa; cần bổ sung bài học và backend nếu muốn phát hành thực tế.
