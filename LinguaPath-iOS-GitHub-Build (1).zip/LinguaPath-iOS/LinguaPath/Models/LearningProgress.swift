import Foundation

@MainActor
final class LearningProgress: ObservableObject {
    @Published var completedLessons: Int { didSet { UserDefaults.standard.set(completedLessons, forKey: "completedLessons") } }
    @Published var totalXP: Int { didSet { UserDefaults.standard.set(totalXP, forKey: "totalXP") } }
    @Published var streak: Int { didSet { UserDefaults.standard.set(streak, forKey: "streak") } }
    @Published var learnedWords: Set<String> {
        didSet { UserDefaults.standard.set(Array(learnedWords), forKey: "learnedWords") }
    }

    init() {
        completedLessons = UserDefaults.standard.integer(forKey: "completedLessons")
        totalXP = UserDefaults.standard.integer(forKey: "totalXP")
        streak = UserDefaults.standard.integer(forKey: "streak")
        learnedWords = Set(UserDefaults.standard.stringArray(forKey: "learnedWords") ?? [])
    }

    func finishLesson(words: [String]) {
        completedLessons += 1
        totalXP += 10
        streak = max(streak, 1)
        learnedWords.formUnion(words)
    }
}
