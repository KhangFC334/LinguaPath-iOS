import Foundation

struct LessonQuestion: Identifiable {
    let id = UUID()
    let prompt: String
    let choices: [String]
    let answer: String
    let explanation: String
    let speakText: String?
}

enum SampleCourse {
    static let questions: [LessonQuestion] = [
        .init(prompt: "Bonjour", choices: ["Xin chào", "Tạm biệt", "Cảm ơn"], answer: "Xin chào", explanation: "Bonjour là lời chào phổ biến trong tiếng Pháp.", speakText: "Bonjour"),
        .init(prompt: "Merci", choices: ["Xin lỗi", "Cảm ơn", "Làm ơn"], answer: "Cảm ơn", explanation: "Merci có nghĩa là cảm ơn.", speakText: "Merci"),
        .init(prompt: "Comment ça va ?", choices: ["Bạn tên gì?", "Bạn khỏe không?", "Bạn ở đâu?"], answer: "Bạn khỏe không?", explanation: "Comment ça va ? dùng để hỏi thăm sức khỏe.", speakText: "Comment ça va ?"),
        .init(prompt: "Au revoir", choices: ["Chúc mừng", "Chào buổi sáng", "Tạm biệt"], answer: "Tạm biệt", explanation: "Au revoir có nghĩa là tạm biệt.", speakText: "Au revoir")
    ]
}
