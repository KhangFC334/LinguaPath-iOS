import SwiftUI

@main
struct LinguaPathApp: App {
    @StateObject private var progress = LearningProgress()
    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(progress)
                .preferredColorScheme(.light)
        }
    }
}
