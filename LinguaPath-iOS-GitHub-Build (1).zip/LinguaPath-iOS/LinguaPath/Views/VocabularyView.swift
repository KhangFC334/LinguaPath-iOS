import SwiftUI

private struct VocabularyEntry: Identifiable {
    let id: String
    let meaning: String
}

struct VocabularyView: View {
    @EnvironmentObject private var progress: LearningProgress
    private let entries = [
        VocabularyEntry(id: "Bonjour", meaning: "Xin chào"),
        VocabularyEntry(id: "Merci", meaning: "Cảm ơn"),
        VocabularyEntry(id: "Au revoir", meaning: "Tạm biệt"),
        VocabularyEntry(id: "S'il vous plaît", meaning: "Làm ơn"),
        VocabularyEntry(id: "Oui", meaning: "Vâng"),
        VocabularyEntry(id: "Non", meaning: "Không"),
        VocabularyEntry(id: "Bonne nuit", meaning: "Chúc ngủ ngon")
    ]
    var body: some View {
        NavigationStack {
            List(entries) { entry in
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(entry.id).font(.headline)
                        Text(entry.meaning).font(.subheadline).foregroundStyle(.secondary)
                    }
                    Spacer()
                    if progress.learnedWords.contains(entry.id) {
                        Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                    }
                }.padding(.vertical, 5)
            }
            .navigationTitle("Từ vựng")
        }
    }
}
