import SwiftUI

struct LearningHomeView: View {
    @EnvironmentObject private var progress: LearningProgress
    @State private var showLesson = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Bonjour ! 🇫🇷").font(.system(size: 29, weight: .bold))
                            Text("Tiếp tục hành trình tiếng Pháp của bạn")
                                .font(.subheadline).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "flame.fill").foregroundStyle(.orange)
                        Text("\(progress.streak)").fontWeight(.bold)
                    }
                    HStack(spacing: 12) {
                        StatCard(title: "XP", value: "\(progress.totalXP)", icon: "bolt.fill")
                        StatCard(title: "Bài đã học", value: "\(progress.completedLessons)", icon: "checkmark.seal.fill")
                    }
                    VStack(alignment: .leading, spacing: 14) {
                        Text("LỘ TRÌNH CỦA BẠN").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                        HStack(spacing: 14) {
                            ZStack {
                                Circle().fill(Color.green.opacity(0.14)).frame(width: 62, height: 62)
                                Image(systemName: "hand.wave.fill").font(.system(size: 25)).foregroundStyle(.green)
                            }
                            VStack(alignment: .leading, spacing: 5) {
                                Text("Cơ bản · Bài 1").font(.headline)
                                Text("Chào hỏi và làm quen").font(.subheadline).foregroundStyle(.secondary)
                                Text("4 câu hỏi · khoảng 3 phút").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                        }
                        Button { showLesson = true } label: {
                            Text("BẮT ĐẦU HỌC").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 16)
                                .background(Color(red: 0.20, green: 0.62, blue: 0.43)).foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                    }
                    .padding(18).background(.white).clipShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(.black.opacity(0.06)))
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Chế độ học tập tập trung", systemImage: "sparkles")
                            .font(.headline)
                        Text("Không quảng cáo trong ứng dụng mẫu. Luyện tập không giới hạn và ôn lại từ đã học.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    .padding(18).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.green.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 18))
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showLesson) { LessonView() }
        }
    }
}

private struct StatCard: View {
    let title: String; let value: String; let icon: String
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: icon).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.title2.bold())
        }.frame(maxWidth: .infinity, alignment: .leading).padding(15)
            .background(.white).clipShape(RoundedRectangle(cornerRadius: 16))
    }
}
