import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            LearningHomeView()
                .tabItem { Label("Học", systemImage: "book.fill") }
            VocabularyView()
                .tabItem { Label("Từ vựng", systemImage: "character.book.closed.fill") }
            ProgressViewScreen()
                .tabItem { Label("Tiến độ", systemImage: "chart.bar.fill") }
        }
        .tint(Color(red: 0.20, green: 0.62, blue: 0.43))
    }
}
