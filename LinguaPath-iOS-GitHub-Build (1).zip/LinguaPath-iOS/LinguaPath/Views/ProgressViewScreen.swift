import SwiftUI

struct ProgressViewScreen: View {
    @EnvironmentObject private var progress: LearningProgress
    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                Image(systemName: "chart.line.uptrend.xyaxis").font(.system(size: 54)).foregroundStyle(.green).padding(.top, 35)
                Text("Tiến độ học tập").font(.title.bold())
                HStack(spacing: 12) {
                    metric("Tổng XP", "\(progress.totalXP)", "bolt.fill")
                    metric("Bài hoàn thành", "\(progress.completedLessons)", "checkmark.seal.fill")
                }
                metric("Từ đã gặp", "\(progress.learnedWords.count)", "character.book.closed.fill")
                Text("Dữ liệu được lưu trực tiếp trên thiết bị.").font(.footnote).foregroundStyle(.secondary)
                Spacer()
            }.padding().background(Color(.systemGroupedBackground)).navigationTitle("Thống kê")
        }
    }
    private func metric(_ title: String, _ value: String, _ icon: String) -> some View {
        VStack(spacing: 8) { Image(systemName: icon).foregroundStyle(.green); Text(value).font(.title.bold()); Text(title).font(.caption).foregroundStyle(.secondary) }
            .frame(maxWidth: .infinity).padding(18).background(.white).clipShape(RoundedRectangle(cornerRadius: 16))
    }
}
