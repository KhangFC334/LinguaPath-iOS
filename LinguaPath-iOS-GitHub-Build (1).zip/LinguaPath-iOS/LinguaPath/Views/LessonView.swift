import SwiftUI
import AVFoundation

struct LessonView: View {
    @EnvironmentObject private var progress: LearningProgress
    @Environment(\.dismiss) private var dismiss
    @State private var index = 0
    @State private var selected: String? = nil
    @State private var checked = false
    @State private var correctCount = 0
    @State private var finished = false
    private let speech = AVSpeechSynthesizer()
    private let questions = SampleCourse.questions

    var body: some View {
        NavigationStack {
            Group {
                if finished { completionView }
                else { questionView }
            }
            .padding()
            .background(Color(.systemGroupedBackground))
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Đóng") { dismiss() } }
                ToolbarItem(placement: .principal) { Text("Bài học · \(min(index + 1, questions.count))/\(questions.count)").font(.subheadline.weight(.semibold)) }
            }
        }
    }

    private var questionView: some View {
        VStack(alignment: .leading, spacing: 22) {
            ProgressView(value: Double(index), total: Double(questions.count)).tint(.green)
            Text("CHỌN NGHĨA ĐÚNG").font(.caption.weight(.bold)).foregroundStyle(.secondary)
            Text(questions[index].prompt).font(.system(size: 34, weight: .bold))
            if let speak = questions[index].speakText {
                Button { speakFrench(speak) } label: { Label("Nghe phát âm", systemImage: "speaker.wave.2.fill") }
                    .buttonStyle(.bordered).tint(.green)
            }
            ForEach(questions[index].choices, id: \.self) { choice in
                Button { if !checked { selected = choice } } label: {
                    HStack { Text(choice).font(.body.weight(.semibold)); Spacer(); if selected == choice { Image(systemName: "checkmark.circle.fill") } }
                        .padding(17).frame(maxWidth: .infinity, alignment: .leading)
                        .background(optionColor(choice)).clipShape(RoundedRectangle(cornerRadius: 14))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(selected == choice ? Color.green : Color.gray.opacity(0.2), lineWidth: 1.5))
                }.buttonStyle(.plain).disabled(checked)
            }
            Spacer(minLength: 0)
            if checked {
                Text(questions[index].explanation).font(.subheadline).frame(maxWidth: .infinity, alignment: .leading)
                    .padding(14).background(Color.green.opacity(0.10)).clipShape(RoundedRectangle(cornerRadius: 12))
            }
            Button { advance() } label: {
                Text(checked ? (index == questions.count - 1 ? "HOÀN THÀNH" : "TIẾP TỤC") : "KIỂM TRA")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 16)
                    .background(selected == nil && !checked ? Color.gray.opacity(0.3) : Color.green)
                    .foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 14))
            }.disabled(selected == nil && !checked)
        }
    }

    private func optionColor(_ choice: String) -> Color {
        guard checked else { return selected == choice ? Color.green.opacity(0.12) : .white }
        if choice == questions[index].answer { return Color.green.opacity(0.15) }
        if choice == selected { return Color.red.opacity(0.12) }
        return .white
    }

    private func advance() {
        if !checked {
            checked = true
            if selected == questions[index].answer { correctCount += 1 }
        } else if index == questions.count - 1 {
            progress.finishLesson(words: questions.map(\.prompt))
            finished = true
        } else {
            index += 1; selected = nil; checked = false
        }
    }

    private var completionView: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "trophy.fill").font(.system(size: 68)).foregroundStyle(.yellow)
            Text("Tuyệt vời!").font(.largeTitle.bold())
            Text("Bạn đã hoàn thành bài học.").foregroundStyle(.secondary)
            Text("+10 XP").font(.title2.bold()).foregroundStyle(.green)
            Text("Số câu đúng: \(correctCount)/\(questions.count)").font(.headline)
            Spacer()
            Button("TIẾP TỤC") { dismiss() }.font(.headline).frame(maxWidth: .infinity).padding(.vertical, 16)
                .background(Color.green).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 14))
        }.padding(.vertical, 25)
    }

    private func speakFrench(_ text: String) {
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "fr-FR")
        utterance.rate = 0.46
        speech.speak(utterance)
    }
}
